package tech.codehunt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxibookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
